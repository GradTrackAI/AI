import { AdmissionForm } from "@/components/ui/admissionForm";

export default function Home() {
  return (
    <AdmissionForm />
  );
}
